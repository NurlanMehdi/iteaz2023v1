# **ITE WEB SITE - FRONT END**
**[https://ite-front.herokuapp.com/](https://ite-front.herokuapp.com/)**
****

**İstifadə olunan paketlər:**

    1. Bootstrap (version 5.2.3)
    2. Popper (version 1.11.0)
    3. jQuery (version 3.6.3)
    4. Slick (version 1.8.0)
    5. Favicon (Ite version 1.0)
    6. ITE icons font (version 1.4)
    7. S.F. Pro Text web font (latin) [300, 400 (regular), 500, 600, 700]
